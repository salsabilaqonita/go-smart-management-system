<?php

$con = mysqli_connect("localhost","root","","gosmart") or die("couldn't connect");

?>
